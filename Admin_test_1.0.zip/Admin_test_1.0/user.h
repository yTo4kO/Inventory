#ifndef USER_H
#define USER_H

extern bool admin;
extern QString identificator;

#endif // USER_H
